/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Date;

/**
 *
 * @author Uros
 */
public class Server {
    static ServerSocket ss;
    static Socket s;
    static InputStreamReader isr;
    static BufferedReader br;
    static String message;
    
    //mysql server
    Connection conn = null;
    private static final String USERNAME2 = "root";
    private static final String PASSWORD2 = "Sifra123/**55";
    private static final String CONN_STRING2 = "jdbc:mysql://localhost:3306/knjizara2";
    
    PrintStream ps;
    
    public void testirajServer() throws InterruptedException {
        try {
//            System.out.println(s.getInetAddress());
//                    ps = new PrintStream(s.getOutputStream()); 
            ss = new ServerSocket(7800);
            System.out.println("pokrenut\n");
            while(true) {
                s = ss.accept();

                isr = new InputStreamReader(s.getInputStream());
                br = new BufferedReader(isr);
                message = br.readLine();
                
                if(message == null) {
                    continue;
                }
                else if(message.equals("najpKnjige")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    
                    ArrayList<ArrayList> lista = getNajpKnjige();
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                    
                }
                else if(message.equals("besplKnjige")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    
                    ArrayList<ArrayList> lista = getBesplKnjige();
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.equals("hronLista")) {
                    
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    ArrayList<ArrayList> lista = getHronLista();
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("mojeKnjige")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    int id = Integer.parseInt(message.split(" ")[1]);
                    ArrayList<ArrayList> lista = getMojeKnjige(id);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("ids")) {
                    String[] info = message.split(" ");
                    int duzina = info.length-2;
                    String idNarudzbine = info[duzina];
                    String idKorisnika = info[duzina+1];
                    Date sqlDate = new java.sql.Date(System.currentTimeMillis()); 
                    String upitNar = String.format("INSERT INTO narudzbine(korisnik_id,datumnarucivanja,placeno) VALUES (%s,'%s',true);",idKorisnika,sqlDate.toString());

                    naruci(upitNar, null);
                    for(int i = 1; i<duzina;i++) {
                        String upitStavka = String.format("INSERT INTO stavkenarudzbine (narudzbina_id,knjiga_id,kolicina) VALUES(%s,%s,1)",
                                idNarudzbine,info[i]);
                        naruci(null,upitStavka);
                    }
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    ArrayList<ArrayList> lista = null;
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("id")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    String isbn = message.split(" ")[1];
                    ArrayList<ArrayList> lista = getKnjiga(isbn);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("komentari")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    String isbn = message.split(" ")[1];
                    ArrayList<ArrayList> lista = getKomentariNaKnjigama(isbn);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("kategorija")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    String kategorija = message.split(" ")[1];
                    ArrayList<ArrayList> lista = getKnjigeIzKategorije(kategorija);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.equals("countOsoba")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    ArrayList<ArrayList> lista = getCountOsoba();
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                else if(message.startsWith("addUser")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    
                    String deo = message.split("addUser ")[1];
                    String queryOsoba = deo.split(";")[0]+";";
                    String queryKorisnik = deo.split(";")[1]+";";
                    
                    ArrayList<ArrayList> lista = addUser(queryOsoba,queryKorisnik);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                else if(message.startsWith("getUser")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    String username = message.split(" ")[1];
                    String sifra =  message.split(" ")[2];
                    ArrayList<ArrayList> lista = getUser(username,sifra);
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.equals("countNarudzbine")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    ArrayList<ArrayList> lista = getCountNarudzbine();
                    
                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                else if(message.startsWith("koMentarisi")) {
                    ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                    String idKnjige = message.split(" ")[1];
                    String userID = message.split(" ")[2];
                    String komentar = message.split("komentar:")[1];
                    String query = String.format("INSERT INTO komentarinaknjigama(datum,knjiga_id,korisnik_id,komentar) VALUES(NOW(),%s,%s,'%s');",idKnjige,userID,komentar);
                    ArrayList<ArrayList> lista = komentarisiKnjigu(query);

                    if(lista!=null){
                        os.writeObject(lista);
                    }
                    else{
                        os.writeObject(null);
                    }
                }
                
                
                else if(message.equals("test")) {
                    System.out.println("poruka: " + message);
                }
                
                
            }
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public ArrayList<ArrayList> komentarisiKnjigu(String query) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
                        Statement stmt1 = conn.createStatement();
            stmt1.executeUpdate(query);
            
            stmt1.close();
            conn.close();
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<ArrayList> getNajpKnjige() {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = "SELECT * FROM najpopularnijeknjige LIMIT 7;";
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> najpKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();

                String isbn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                String izdavac = rezultati.getString("izdavac");
                String id = rezultati.getString("id");
                
                red.add(isbn);
                red.add(naslov);
                red.add(cena);
                red.add(autor);
                red.add(izdavac);
                red.add(id);
                
                najpKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return najpKnjige;
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<ArrayList> getBesplKnjige() {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = "SELECT * FROM besplatneknjige;";
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> bespKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();

                String isbn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                String izdavac = rezultati.getString("izdavac");
                String id = rezultati.getString("id");
                
                red.add(isbn);
                red.add(naslov);
                red.add(cena);
                red.add(autor);
                red.add(izdavac);
                red.add(id);
                
                
                bespKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return bespKnjige;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
        
    
    }
    public ArrayList<ArrayList> getHronLista() {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = "SELECT * FROM hronoloskalista;";
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> bespKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();

                String isbn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                String izdavac = rezultati.getString("izdavac");
                String id = rezultati.getString("id");
                
                red.add(isbn);
                red.add(naslov);
                red.add(cena);
                red.add(autor);
                red.add(izdavac);
                red.add(id);
                
                bespKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return bespKnjige;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
    }

    private ArrayList<ArrayList> getMojeKnjige(int id) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT * FROM knjigeKorisnika WHERE korisnik_id = %s ;",String.valueOf(id));
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> bespKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String isbn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                
                red.add(isbn);
                red.add(naslov);
                red.add(cena);
                red.add(autor);
                
                bespKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return bespKnjige;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
    }
    
    public ArrayList<ArrayList> getKnjiga(String idd) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT * FROM knjige_mobilno WHERE id = '%s' ;",idd);
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> bespKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String isbnn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                String strana = rezultati.getString("strana");
                String godinaIzdanja = rezultati.getString("godinaizdanja");
                String kategorija = rezultati.getString("kategorija");
                String izdavac = rezultati.getString("ime");
                String id = rezultati.getString("id");

                red.add(isbnn); // 0
                red.add(naslov); // 1
                red.add(cena); // 2
                red.add(autor); // 3
                red.add(strana); // 4
                red.add(godinaIzdanja); // 5
                red.add(kategorija); // 6
                red.add(izdavac); // 7
                red.add(id);
                
                
                bespKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return bespKnjige;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
        
    }
    
    public ArrayList<ArrayList> getKomentariNaKnjigama(String isbn) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT * FROM komentari_mobilno WHERE id = '%s' ;",isbn);
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> bespKnjige = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String komentar = rezultati.getString("komentar");
                String korisnik = rezultati.getString("korisnik");
                String isbnn = rezultati.getString("isbn");

                red.add(komentar);
                red.add(korisnik);
                red.add(isbnn);
                
                bespKnjige.add(red);
            }
            stmt.close();
            conn.close();
            return bespKnjige;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
        
    }
    
    public ArrayList<ArrayList> getKnjigeIzKategorije(String kategorija) {
        try {
            
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT isbn,naslov,cena,autor,ime,godinaizdanja,id FROM knjige_mobilno WHERE kategorija  = '%s';",kategorija);
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> lista = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String isbn = rezultati.getString("isbn");
                String naslov = rezultati.getString("naslov");
                String cena = rezultati.getString("cena");
                String autor = rezultati.getString("autor");
                String godinaizdanja = rezultati.getString("godinaizdanja");
                String id = rezultati.getString("id");
                
                red.add(isbn);
                red.add(naslov);
                red.add(cena);
                red.add(autor);
                red.add(godinaizdanja);
                red.add(id);
                
                lista.add(red);
            }
            stmt.close();
            conn.close();
            return lista;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
        
    }
    public ArrayList<ArrayList> getUser(String username,String sifra) {
        try{
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT username,id FROM osoba WHERE username = '%s' AND sifra = '%s'",username,sifra); 
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> lista = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                String username0 = rezultati.getString("username");
                String id = rezultati.getString("id");
                
                red.add(username0);
                red.add(id);
                
                lista.add(red);
            }
            stmt.close();
            conn.close();
            return lista;
        
        }
            catch(Exception e) {

            }
        
        return null;
             
    }
    public ArrayList<ArrayList> getCountOsoba() {
        try {
            
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT COUNT(id)+1 as 'ukupno' FROM osoba;");
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> lista = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String isbn = rezultati.getString("ukupno");
                
                
                red.add(isbn);
                
                lista.add(red);
            }
            stmt.close();
            conn.close();
            return lista;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
    }
    
    public ArrayList<ArrayList> addUser(String queryOsoba,String queryKorisnik) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);

            
            Statement stmt1 = conn.createStatement();
            stmt1.executeUpdate(queryOsoba);
            
            Statement stmt2 = conn.createStatement();
            stmt2.executeUpdate(queryKorisnik);
            
            stmt1.close();
            stmt2.close();

            conn.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private ArrayList<ArrayList> getCountNarudzbine() {
        try {
            
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            String primer = String.format("SELECT COUNT(id)+1 as 'ukupno' FROM narudzbine;");
            Statement stmt = conn.createStatement();
            ResultSet rezultati = stmt.executeQuery(primer);
            ArrayList<ArrayList> lista = new ArrayList<ArrayList>();
            
            while (rezultati.next()) {
                ArrayList<String> red = new ArrayList<String>();
                
                String isbn = rezultati.getString("ukupno");
                
                red.add(isbn);
                
                lista.add(red);
            }
            stmt.close();
            conn.close();
            return lista;
            
            
            
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
    }
    
    public ArrayList<ArrayList> naruci(String narudzbina,String stavke) {
        try {
            conn = DriverManager.getConnection(CONN_STRING2,USERNAME2, PASSWORD2);
            Statement stmt1;
            
            if(narudzbina!=null) {
                stmt1 = conn.createStatement();
                stmt1.executeUpdate(narudzbina);
                stmt1.close();
                conn.close();
            }
            if(stavke!=null) {
                stmt1 = conn.createStatement();
                stmt1.executeUpdate(stavke);
                stmt1.close();
                conn.close();
            }
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    
    
    
}
